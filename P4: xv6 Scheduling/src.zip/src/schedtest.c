#include "user.h"
#include "pstat.h"

int main(int argc, char **argv) {
  if(argc != 6) {
    printf(2, "Usage: schedtest sliceA sleepA sliceB sleepB sleepParent\n");
    exit();
  }

  struct pstat stat;
  int pidA = -1;
  int pidB = -1;
  int comptickA = -1;
  int comptickB = -1;

  pidA = fork2(atoi(argv[1]));
  if (pidA == 0) { // Child A
    char *args[3] = {"loop", argv[2], '\0'};
    exec(args[0], args);
  } else {
    pidB = fork2(atoi(argv[3]));
    if (pidB == 0) { // Child B
        char *args[3] = {"loop", argv[4], '\0'};
        exec(args[0], args);
    } else {
        sleep(atoi(argv[5]));
        if (getpinfo(&stat) == 0) {
            for (int i = 0; i < NPROC; i++) {
                if (stat.inuse[i] == 1 && pidA == stat.pid[i]) {
                    comptickA = stat.compticks[i];
                }
                if (stat.inuse[i] == 1 && pidB == stat.pid[i]) {
                    comptickB = stat.compticks[i];
                }
            }
            printf(1, "%d %d\n", comptickA, comptickB);
        }
        wait();
        wait();
        exit();
    }
  }
}
    
